# Installation
> `npm install --save @types/dragula`

# Summary
This package contains type definitions for dragula (http://bevacqua.github.io/dragula/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/dragula

Additional Details
 * Last updated: Sat, 27 Oct 2018 06:22:24 GMT
 * Dependencies: none
 * Global values: dragula

# Credits
These definitions were written by Paul Welter <https://github.com/pwelter34>, Yang He <https://github.com/abruzzihraig>.
