Please see the [complete README on GitHub](https://github.com/valor-software/ng2-dragula/)
